Info
--------------------------------------------------------------------------------------
Package for installing Ralink corp. RT3290 Linux STA wireless driver on Ubuntu 15.04 based distributions

Official MediaTek driver patched to fix compiling against Ubuntu 15.04 Linux kernel

Requirements:

    Ubuntu 15.04 or latest
    Internet connection for downloading and installing driver compilation dependencies

-------------------------------------------------------------------------------------
Installation
--------------------------------------------------------------------------------------

simply run, Run.sh file

--------------------------------------------------------------------------------------
Uninstallation
--------------------------------------------------------------------------------------

simply run, sudo ./uninstall.sh in the terminal

--------------------------------------------------------------------------------------------------------------------
Driver package author
--------------------------------------------------------------------------------------------------------------------
Md Imam Hossain <imamdxl8805@gmail.com>
https://www.youtube.com/channel/UCyIHBlRjiHj-tietbdRHTzA
